from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Room(models.Model):
    """
    Chat room (or call room). Use 'name' as the unique identifier.
    """
    name = models.CharField(max_length=150, unique=True)
    topic = models.CharField(max_length=250, blank=True)
    is_private = models.BooleanField(default=False)
    created_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.name

    def last_messages(self, limit=50):
        return self.messages.order_by("-timestamp")[:limit][::-1]  # ascending order

class Message(models.Model):
    """
    Persisted chat message.
    """
    room = models.ForeignKey(Room, related_name="messages", on_delete=models.CASCADE)
    user = models.CharField(max_length=150)          # store username or guest name
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    edited = models.BooleanField(default=False)

    class Meta:
        ordering = ["timestamp"]

    def __str__(self):
        return f"{self.user}: {self.content[:60]}"

class CallLog(models.Model):
    """
    Record of a call session for dashboard and analytics.
    """
    room = models.ForeignKey(Room, related_name="calls", on_delete=models.SET_NULL, null=True, blank=True)
    caller = models.CharField(max_length=150)
    callee = models.CharField(max_length=150, blank=True)
    started_at = models.DateTimeField(auto_now_add=True)
    ended_at = models.DateTimeField(null=True, blank=True)
    duration_seconds = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=50, default="completed")  # completed, missed, declined
    metadata = models.JSONField(null=True, blank=True)  # optional extra data

    class Meta:
        ordering = ["-started_at"]

    def __str__(self):
        return f"Call {self.caller} → {self.callee or 'unknown'} @ {self.started_at:%Y-%m-%d %H:%M:%S}"

