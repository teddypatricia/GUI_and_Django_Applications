# MyFrame.py
from tkinter.ttk import Frame, Button, Label, Entry, Style, Treeview
from tkinter import BOTH, END, messagebox, filedialog
import json
import os
from LoanWindow import LoanCalculator

HISTORY_FILE = "calc_history.json"

class MyFrame(Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.calc_window = None
        self.initUI()
        self._load_history()

    def initUI(self):
        self.parent.title("Loan Calculator Launcher")
        Style().theme_use("default")
        self.pack(fill=BOTH, expand=1)

        Label(self, text="Last saved file:").place(x=20, y=18)
        self.file_entry = Entry(self)
        self.file_entry.place(x=130, y=18, width=260)

        Button(self, text="Open Calculator", command=self.open_calc).place(x=20, y=60, width=140)
        Button(self, text="Save Current (JSON)", command=self.save_current).place(x=180, y=60, width=140)
        Button(self, text="Load JSON", command=self.load_json).place(x=340, y=60, width=100)

        Label(self, text="History (recent calculations)").place(x=20, y=110)
        self.tree = Treeview(self, columns=("amount","rate","duration","monthly","total"), show="headings")
        self.tree.heading("amount", text="Amount")
        self.tree.heading("rate", text="Rate")
        self.tree.heading("duration", text="Months")
        self.tree.heading("monthly", text="Monthly")
        self.tree.heading("total", text="Total")
        self.tree.place(x=20, y=140, width=560, height=220)

        Button(self, text="Export Selected CSV", command=self.export_selected).place(x=20, y=370, width=160)
        Button(self, text="Clear History", command=self.clear_history).place(x=200, y=370, width=120)

    def open_calc(self):
        if self.calc_window is None or not getattr(self.calc_window, "winfo_exists", lambda: False)():
            self.calc_window = LoanCalculator(self.parent)
        else:
            self.calc_window.focus()

    def save_current(self):
        if not (self.calc_window and self.calc_window.winfo_exists()):
            messagebox.showinfo("No calculator", "Open the calculator and compute values before saving.")
            return
        data = {
            "amount": self.calc_window.amount.get(),
            "rate": self.calc_window.rate.get(),
            "duration": self.calc_window.duration.get(),
            "monthly": self.calc_window.monthly.get(),
            "total": self.calc_window.total.get()
        }
        # append to history file
        history = []
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r") as f:
                try:
                    history = json.load(f)
                except:
                    history = []
        history.insert(0, data)  # newest first
        history = history[:200]  # keep last 200
        with open(HISTORY_FILE, "w") as f:
            json.dump(history, f, indent=2)
        self.file_entry.delete(0, END)
        self.file_entry.insert(0, os.path.abspath(HISTORY_FILE))
        self._refresh_tree(history)
        messagebox.showinfo("Saved", "Current calculation saved to history.")

    def _load_history(self):
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r") as f:
                try:
                    history = json.load(f)
                except:
                    history = []
            self._refresh_tree(history)
        else:
            self._refresh_tree([])

    def _refresh_tree(self, history):
        for r in self.tree.get_children():
            self.tree.delete(r)
        for rec in history:
            self.tree.insert("", END, values=(rec.get("amount"), rec.get("rate"), rec.get("duration"), rec.get("monthly"), rec.get("total")))

    def load_json(self):
        fname = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if not fname:
            return
        with open(fname, "r") as f:
            try:
                data = json.load(f)
            except Exception as e:
                messagebox.showerror("Failed", f"Could not load JSON: {e}")
                return
        self.open_calc()
        c = self.calc_window
        c.amount.delete(0, END); c.amount.insert(0, data.get("amount",""))
        c.rate.delete(0, END); c.rate.insert(0, data.get("rate",""))
        c.duration.delete(0, END); c.duration.insert(0, data.get("duration",""))
        # attempt to calculate to fill monthly/total
        try:
            c.calc()
        except Exception:
            pass
        messagebox.showinfo("Loaded", f"Loaded config from {fname}")

    def export_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("No selection", "Select a history row to export.")
            return
        values = self.tree.item(sel[0], "values")
        fname = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV","*.csv")])
        if not fname:
            return
        import csv
        with open(fname, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["amount","rate","duration","monthly","total"])
            writer.writerow(values)
        messagebox.showinfo("Exported", f"Exported selected calculation to {fname}")

    def clear_history(self):
        if messagebox.askyesno("Confirm", "Clear saved history?"):
            if os.path.exists(HISTORY_FILE):
                os.remove(HISTORY_FILE)
            self._refresh_tree([])
            messagebox.showinfo("Cleared", "History cleared.")
