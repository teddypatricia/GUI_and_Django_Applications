# LoanWindow.py
from tkinter import Toplevel, END, messagebox
from tkinter.ttk import Style, Button, Label, Entry
import math

class LoanCalculator(Toplevel):
    """ A modeless loan calculator window with validation and amortization export.  """

    def __init__(self, master=None):
        super().__init__(master)
        self.initUI()

    def initUI(self):
        self.title("Loan Calculator")
        self.geometry("420x360")
        Style().theme_use("default")

        x1 = 20
        y = 20
        x2 = 220

        Label(self, text="Loan Amount").place(x=x1, y=y)
        self.amount = Entry(self)
        self.amount.place(x=x2, y=y, width=160)

        y += 40
        Label(self, text="Annual Rate (%)").place(x=x1, y=y)
        self.rate = Entry(self)
        self.rate.place(x=x2, y=y, width=160)

        y += 40
        Label(self, text="Duration (months)").place(x=x1, y=y)
        self.duration = Entry(self)
        self.duration.place(x=x2, y=y, width=160)

        y += 40
        Label(self, text="Monthly Payment").place(x=x1, y=y)
        self.monthly = Entry(self, state="readonly")
        self.monthly.place(x=x2, y=y, width=160)

        y += 40
        Label(self, text="Total Payment").place(x=x1, y=y)
        self.total = Entry(self, state="readonly")
        self.total.place(x=x2, y=y, width=160)

        y += 55
        Button(self, text="Calculate", command=self.calc).place(x=40, y=y, width=100)
        Button(self, text="Clear", command=self.clear_fields).place(x=160, y=y, width=80)
        Button(self, text="Export Amortization (CSV)", command=self.export_amortization).place(x=260, y=y, width=140)

    def clear_fields(self):
        for e in (self.amount, self.rate, self.duration):
            e.delete(0, END)
        for e in (self.monthly, self.total):
            e.config(state="normal")
            e.delete(0, END)
            e.config(state="readonly")

    def _validate_inputs(self):
        """
        Validate and return numeric (amount, rate, duration).
        Raises ValueError on invalid input.
        """
        try:
            amount = float(self.amount.get())
            rate = float(self.rate.get())
            duration = int(float(self.duration.get()))
        except ValueError:
            raise ValueError("Amount, Rate and Duration must be numeric.")

        if amount <= 0:
            raise ValueError("Amount must be greater than 0.")
        if rate < 0:
            raise ValueError("Rate cannot be negative.")
        if duration <= 0:
            raise ValueError("Duration (months) must be positive.")

        return amount, rate, duration

    def calc(self):
        """
        Calculate monthly and total payment and populate fields.
        """
        try:
            amount, rate, duration = self._validate_inputs()
        except ValueError as e:
            messagebox.showerror("Invalid input", str(e))
            return

        monthly_rate = rate / 1200.0  # percent -> decimal per month

        if monthly_rate == 0:
            monthly_payment = amount / duration
        else:
            monthly_payment = amount * (monthly_rate * (1 + monthly_rate) ** duration) / ((1 + monthly_rate) ** duration - 1)

        total_payment = monthly_payment * duration

        self.monthly.config(state="normal")
        self.monthly.delete(0, END)
        self.monthly.insert(0, f"{monthly_payment:.2f}")
        self.monthly.config(state="readonly")

        self.total.config(state="normal")
        self.total.delete(0, END)
        self.total.insert(0, f"{total_payment:.2f}")
        self.total.config(state="readonly")

    def export_amortization(self):
        """
        Build full amortization schedule and export to CSV (asks user for filename).
        """
        from tkinter import filedialog
        try:
            amount, rate, duration = self._validate_inputs()
        except ValueError as e:
            messagebox.showerror("Invalid input", str(e))
            return

        monthly_rate = rate / 1200.0
        if monthly_rate == 0:
            monthly_payment = amount / duration
        else:
            monthly_payment = amount * (monthly_rate * (1 + monthly_rate) ** duration) / ((1 + monthly_rate) ** duration - 1)

        balance = amount
        schedule = []
        for month in range(1, duration + 1):
            if monthly_rate == 0:
                interest = 0.0
                principal = monthly_payment
            else:
                interest = balance * monthly_rate
                principal = monthly_payment - interest
            # Fix rounding issues for last payment
            if principal > balance:
                principal = balance
                monthly_payment = principal + interest
            balance = max(0.0, balance - principal)
            schedule.append({
                "month": month,
                "payment": round(monthly_payment, 2),
                "principal": round(principal, 2),
                "interest": round(interest, 2),
                "balance": round(balance, 2)
            })

        # Asking for filename and writing CSV
        fname = filedialog.asksaveasfilename(defaultextension=".csv",
                                             filetypes=[("CSV files", "*.csv")])
        if not fname:
            return
        import csv
        with open(fname, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Month", "Payment", "Principal", "Interest", "Balance"])
            for r in schedule:
                writer.writerow([r["month"], f"{r['payment']:.2f}", f"{r['principal']:.2f}", f"{r['interest']:.2f}", f"{r['balance']:.2f}"])
        messagebox.showinfo("Exported", f"Amortization schedule exported to:\n{fname}")
