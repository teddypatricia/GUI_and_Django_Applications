from django.shortcuts import render
from .models import Room, Message

def index(request):
    rooms = Room.objects.all()
    return render(request, "chatcall/index.html", {"rooms": rooms})

def room_view(request, room_id):
    room = Room.objects.get(id=room_id)
    messages = room.messages.all()  # related_name="messages"
    return render(request, "chatcall/room.html", {"room": room, "messages": messages})









