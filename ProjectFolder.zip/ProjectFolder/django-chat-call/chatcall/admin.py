from django.contrib import admin
from .models import Room, Message, CallLog

@admin.register(Room)
class RoomAdmin(admin.ModelAdmin):
    list_display = ("name", "topic", "is_private", "created_by", "created_at")
    search_fields = ("name", "topic", "created_by__username")
    list_filter = ("is_private",)

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ("room", "user", "short_content", "timestamp")
    search_fields = ("content", "user")
    list_filter = ("timestamp",)
    date_hierarchy = "timestamp"

    def short_content(self, obj):
        return (obj.content[:75] + "...") if len(obj.content) > 75 else obj.content
    short_content.short_description = "Content"

@admin.register(CallLog)
class CallLogAdmin(admin.ModelAdmin):
    list_display = ("room", "caller", "callee", "started_at", "ended_at", "status")
    search_fields = ("caller", "callee", "status")
    date_hierarchy = "started_at"

