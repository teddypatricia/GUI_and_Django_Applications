# main.py
import sys
from tkinter import Tk
from MyFrame import MyFrame

def main():
    root = Tk()
    root.geometry("620x420")
    app = MyFrame(root)
    root.mainloop()

if __name__ == "__main__":
    main()
